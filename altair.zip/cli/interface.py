"""
SUP Core - Command Line Interface
Primary user control layer.
"""

import json
import sys
import os
import time
from datetime import datetime


class CLI:
    """
    Command Line Interface for SUP Core.
    Provides user control over all system components.
    """

    def __init__(self, system):
        self.system = system
        self.running = True
        self.commands = {
            "help":        (self.cmd_help, "Show all commands"),
            "status":      (self.cmd_status, "Show system status"),
            "device":      (self.cmd_device, "Show device information"),
            "memory":      (self.cmd_memory, "Memory operations [stats|get|set|search|export]"),
            "intelligence":(self.cmd_intelligence, "Intelligence core [status|risks|query|observations]"),
            "balance":     (self.cmd_balance, "Balance manager [status|metrics|history]"),
            "evolution":   (self.cmd_evolution, "Evolution engine [status|mode|history|propose]"),
            "automation":  (self.cmd_automation, "Automation [status|list|add|remove|history]"),
            "security":    (self.cmd_security, "Security [status|events|setkey|auth|override]"),
            "save":        (self.cmd_save, "Force save all memory"),
            "node":        (self.cmd_node, "Node system manager [list|spawn|kill]"),
            "clear":       (self.cmd_clear, "Clear screen"),
            "exit":        (self.cmd_exit, "Shutdown and exit"),
            "quit":        (self.cmd_exit, "Shutdown and exit"),
        }

    def start(self):
        """Start the CLI loop."""
        self._print_banner()
        print(f"  Device: {self.system['device'].device_type} | "
              f"OS: {self.system['device'].platform_system} | "
              f"RAM: {self.system['device'].capabilities['total_memory_mb']}MB")
        print(f"  Memory loaded | Intelligence active | Type 'help' for commands\n")

        while self.running:
            try:
                raw = input("\033[1;36mSUP>\033[0m ").strip()
                if not raw:
                    continue

                parts = raw.split(maxsplit=1)
                cmd = parts[0].lower()
                args = parts[1] if len(parts) > 1 else ""

                if cmd in self.commands:
                    handler, _ = self.commands[cmd]
                    handler(args)
                else:
                    print(f"  Unknown command: '{cmd}'. Type 'help' for available commands.")

            except KeyboardInterrupt:
                print("\n  Use 'exit' to shutdown safely.")
            except EOFError:
                self.cmd_exit("")

    def _print_banner(self):
        """Print the system banner."""
        from config.settings import BANNER
        print(BANNER)

    def _pp(self, data, indent=2):
        """Pretty print data."""
        if isinstance(data, dict) or isinstance(data, list):
            print(json.dumps(data, indent=indent, default=str))
        else:
            print(data)

    # === COMMANDS ===

    def cmd_help(self, args):
        """Show help with final fixed padding logic."""
        # စုစုပေါင်း အကျယ်ကို ၇၀ လို့ သတ်မှတ်တယ်
        w = 70
        print("\n  ┌" + "─" * (w - 2) + "┐")
        print("  │" + "Altair v.1.0.0 — Command Reference".center(w - 2) + "│")
        print("  ├" + "─" * 15 + "┬" + "─" * (w - 18) + "┤")
        
        for cmd, (_, desc) in sorted(self.commands.items()):
            # cmd ကို ၁၃ နေရာ၊ desc ကို ၅၀ နေရာ အသေ (Fixed) ယူမယ်
            # အပို space တွေကို manual ဖြည့်မယ်
            c_txt = cmd[:13]
            d_txt = desc[:50]
            
            c_pad = " " * (13 - len(c_txt))
            d_pad = " " * (50 - len(d_txt))
            
            # စာသားကြားထဲမှာ space တစ်ခုစီ ခြားမယ်
            print(f"  │ {c_txt}{c_pad} │ {d_txt}{d_pad} │")
            
        print("  └" + "─" * 15 + "┴" + "─" * (w - 18) + "┘\n")


    def cmd_status(self, args):
        """Show full system status."""
        print("\n  ── System Status ─────────────────────────────────")
        print(f"  Device Type     : {self.system['device'].device_type}")
        print(f"  Platform        : {self.system['device'].platform_system} "
              f"({self.system['device'].platform_machine})")

        bal = self.system['balance'].get_status()
        print(f"  System State    : {bal['state']}")
        print(f"  Throttle Level  : {bal['throttle_level']}")
        print(f"  CPU             : {bal['metrics'].get('cpu_percent', 'N/A')}%")
        print(f"  Memory          : {bal['metrics'].get('memory_percent', 'N/A')}%")

        intel = self.system['intelligence'].get_status()
        print(f"  Intelligence    : {'Active' if intel['running'] else 'Inactive'} "
              f"(depth: {intel['depth']})")
        print(f"  Active Risks    : {intel['active_risks']}")

        evo = self.system['evolution'].get_status()
        print(f"  Evolution Mode  : {evo['mode']} ({evo['mode_description']})")
        print(f"  Session Steps   : {evo['session_steps']}/{evo['max_steps_per_session']}")

        auto = self.system['automation'].get_status()
        print(f"  Automation Rules: {auto['active_rules']}/{auto['total_rules']}")

        sec = self.system['security'].get_status()
        print(f"  Threat Level    : {sec['threat_level']}")
        print(f"  Security Key    : {'Set' if sec['master_key_set'] else 'Not Set'}")

        mem_stats = self.system['memory'].get_stats()
        print(f"  Memory Stores   : User({mem_stats['user_memory_keys']} keys), "
              f"System({mem_stats['system_memory_keys']} keys), "
              f"Intel({mem_stats['intelligence_memory_keys']} keys)")
        print(f"  Boot Count      : {mem_stats['startup_count']}")
        print()

    def cmd_device(self, args):
        """Show device info."""
        info = self.system['device'].get_info()
        print("\n  ── Device Information ────────────────────────────")
        self._pp(info)
        print()

    def cmd_memory(self, args):
        """Memory operations."""
        parts = args.split(maxsplit=2)
        subcmd = parts[0].lower() if parts else "stats"

        if subcmd == "stats":
            stats = self.system['memory'].get_stats()
            print("\n  ── Memory Statistics ─────────────────────────────")
            self._pp(stats)

        elif subcmd == "get":
            if len(parts) < 3:
                print("  Usage: memory get <store> <key>")
                print("  Stores: user, system, intelligence")
                return
            store_name = parts[1]
            key = parts[2]
            store = getattr(self.system['memory'], store_name, None)
            if store:
                value = store.get(key)
                print(f"\n  [{store_name}] {key} =")
                self._pp(value)
            else:
                print(f"  Unknown store: {store_name}")

        elif subcmd == "set":
            if len(parts) < 3:
                print("  Usage: memory set <store>.<key> <value>")
                return
            path = parts[1]
            value = parts[2]
            if "." in path:
                store_name, key = path.split(".", 1)
            else:
                print("  Format: store.key (e.g., user.name)")
                return
            store = getattr(self.system['memory'], store_name, None)
            if store:
                # Try to parse value as JSON
                try:
                    value = json.loads(value)
                except (json.JSONDecodeError, ValueError):
                    pass
                store.set(key, value)
                print(f"  Set [{store_name}] {key} = {value}")
            else:
                print(f"  Unknown store: {store_name}")

        elif subcmd == "search":
            if len(parts) < 2:
                print("  Usage: memory search <query>")
                return
            query = parts[1]
            results = self.system['memory'].search(query)
            print(f"\n  Search results for '{query}': {len(results)} matches")
            for r in results[:20]:
                print(f"    {r['path']}: {r['value']}")

        elif subcmd == "export":
            data = self.system['memory'].export_all()
            export_file = os.path.join(
                self.system['memory'].data_dir,
                f"export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            )
            with open(export_file, "w") as f:
                json.dump(data, f, indent=2, default=str)
            print(f"  Memory exported to: {export_file}")

        elif subcmd == "keys":
            store_name = parts[1] if len(parts) > 1 else "user"
            store = getattr(self.system['memory'], store_name, None)
            if store:
                keys = store.keys()
                print(f"\n  [{store_name}] Keys ({len(keys)}):")
                for k in keys:
                    print(f"    - {k}")
            else:
                print(f"  Unknown store: {store_name}")

        else:
            print("  Memory subcommands: stats, get, set, search, export, keys")
        print()

    def cmd_intelligence(self, args):
        """Intelligence core operations."""
        parts = args.split(maxsplit=1)
        subcmd = parts[0].lower() if parts else "status"

        if subcmd == "status":
            status = self.system['intelligence'].get_status()
            print("\n  ── Intelligence Core Status ──────────────────────")
            self._pp(status)

        elif subcmd == "risks":
            risks = self.system['intelligence'].get_risks(10)
            print(f"\n  ── Recent Risks ({len(risks)}) ─────────────────────")
            if risks:
                for r in risks:
                    sev = r.get("severity", "?")
                    msg = r.get("message", "")
                    ts = r.get("timestamp", "")[:19]
                    print(f"  [{sev}] {ts} — {msg}")
            else:
                print("  No risks detected.")

        elif subcmd == "query":
            question = parts[1] if len(parts) > 1 else "status"
            result = self.system['intelligence'].query(question)
            if isinstance(result, dict):
                answer = result.get('answer', 'No answer')
                print(f"\n  Intelligence: {answer}")
                if "risks" in result:
                    for r in result["risks"][:3]:
                        print(f"    [{r['severity']}] {r['message']}")
            else:
                print(f"\n  Intelligence: {result}")

            if "risks" in result:
                for r in result["risks"][:3]:
                    print(f"    [{r['severity']}] {r['message']}")

        elif subcmd == "observations":
            obs = self.system['intelligence'].get_observations(10)
            print(f"\n  ── Recent Observations ({len(obs)}) ──────────────────")
            for o in obs:
                print(f"  Cycle {o['cycle']:>4} | State: {o['system_state']:<10} | "
                      f"CPU: {o['cpu']:>5.1f}% | MEM: {o['memory']:>5.1f}%")

        elif subcmd == "recommendations":
            recs = self.system['intelligence'].get_recommendations()
            print(f"\n  ── Recommendations ({len(recs)}) ────────────────────")
            for r in recs:
                print(f"  [{r['priority']}] {r['type']}: {r['reason']}")

        else:
            print("  Intelligence subcommands: status, risks, query, observations, recommendations")
        print()

    def cmd_balance(self, args):
        """Balance manager operations."""
        parts = args.split(maxsplit=1)
        subcmd = parts[0].lower() if parts else "status"

        if subcmd == "status":
            status = self.system['balance'].get_status()
            print("\n  ── Balance Manager Status ────────────────────────")
            self._pp(status)

        elif subcmd == "metrics":
            metrics = self.system['balance'].metrics
            print("\n  ── Current Metrics ───────────────────────────────")
            self._pp(metrics)

        else:
            print("  Balance subcommands: status, metrics")
        print()

    def cmd_evolution(self, args):
        """Evolution engine operations."""
        parts = args.split(maxsplit=1)
        subcmd = parts[0].lower() if parts else "status"

        if subcmd == "status":
            status = self.system['evolution'].get_status()
            print("\n  ── Evolution Engine Status ───────────────────────")
            self._pp(status)

        elif subcmd == "mode":
            if len(parts) > 1:
                mode = parts[1].upper()
                if mode in ("A", "B"):
                    result = self.system['evolution'].set_mode(mode)
                    if result:
                        print(f"  Evolution mode set to: {mode}")
                        if mode == "B":
                            print("  WARNING: Autonomous evolution enabled.")
                    else:
                        print("  Failed to set mode.")
                else:
                    print("  Modes: A (User Limited) or B (Autonomous)")
            else:
                current = self.system['evolution'].mode
                desc = "User Limited" if current == "A" else "Autonomous Intelligence"
                print(f"  Current mode: {current} ({desc})")

        elif subcmd == "history":
            history = self.system['evolution'].get_history(15)
            print(f"\n  ── Evolution History ({len(history)} steps) ────────────")
            for h in history:
                status_str = "✓" if h["applied"] else "✗"
                rev = " [REVERTED]" if h.get("reverted") else ""
                print(f"  {status_str} [{h['mode']}] {h['step_type']}: "
                      f"{h['description'][:50]}{rev}")

        elif subcmd == "pending":
            pending = self.system['evolution'].get_pending()
            print(f"\n  ── Pending Steps ({len(pending)}) ──────────────────────")
            for p in pending:
                print(f"  ID: {p['id']} | Safety: {p['safety_score']} | "
                      f"{p['description'][:40]}")

        elif subcmd == "propose":
            if len(parts) > 1:
                desc = parts[1]
                step = self.system['evolution'].propose_step(
                    "learn_patterns", desc, {"description": desc}
                )
                print(f"  Proposed step: {step['id']} (safety: {step['safety_score']})")
                print("  Use 'evolution approve <id>' to apply.")
            else:
                print("  Usage: evolution propose <description>")

        elif subcmd == "approve":
            if len(parts) > 1:
                step_id = parts[1].strip()
                result = self.system['evolution'].approve_step(step_id)
                self._pp(result)
            else:
                print("  Usage: evolution approve <step_id>")

        elif subcmd == "reject":
            if len(parts) > 1:
                step_id = parts[1].strip()
                result = self.system['evolution'].reject_step(step_id)
                self._pp(result)
            else:
                print("  Usage: evolution reject <step_id>")

        else:
            print("  Evolution subcommands: status, mode [A|B], history, pending, propose, approve, reject")
        print()

    def cmd_automation(self, args):
        """Automation engine operations."""
        parts = args.split(maxsplit=2)
        subcmd = parts[0].lower() if parts else "status"

        if subcmd == "status":
            status = self.system['automation'].get_status()
            print("\n  ── Automation Engine Status ──────────────────────")
            self._pp(status)

        elif subcmd == "list":
            rules = self.system['automation'].list_rules()
            print(f"\n  ── Automation Rules ({len(rules)}) ─────────────────────")
            for r in rules:
                enabled = "ON " if r["enabled"] else "OFF"
                print(f"  [{enabled}] {r['id'][:8]} | {r['name']:<20} | "
                      f"Triggers: {r['trigger_count']}")

        elif subcmd == "add":
            # Interactive rule creation
            print("\n  ── Add Automation Rule ───────────────────────────")
            try:
                name = input("  Rule name: ").strip()
                print("  Trigger types: system_state, cpu_above, cpu_below, "
                      "memory_above, interval, throttle_level")
                trigger_type = input("  Trigger type: ").strip()

                trigger = {"type": trigger_type}
                if trigger_type == "system_state":
                    trigger["state"] = input("  State (IDLE/LIGHT/BALANCED/HEAVY/CRITICAL): ").strip()
                elif trigger_type in ("cpu_above", "cpu_below", "memory_above"):
                    trigger["threshold"] = float(input("  Threshold (%): ").strip())
                elif trigger_type == "interval":
                    trigger["seconds"] = int(input("  Interval (seconds): ").strip())
                elif trigger_type == "throttle_level":
                    trigger["level"] = int(input("  Level (0-3): ").strip())

                print("  Action types: log_message, alert, set_memory, adjust_balance")
                action_type = input("  Action type: ").strip()
                action = {"type": action_type, "params": {}}

                if action_type in ("log_message", "alert"):
                    action["params"]["message"] = input("  Message: ").strip()
                elif action_type == "set_memory":
                    action["params"]["store"] = input("  Store (user/system): ").strip()
                    action["params"]["key"] = input("  Key: ").strip()
                    action["params"]["value"] = input("  Value: ").strip()

                result = self.system['automation'].add_rule(name, trigger, action)
                self._pp(result)

            except (KeyboardInterrupt, EOFError):
                print("\n  Rule creation cancelled.")

        elif subcmd == "remove":
            if len(parts) > 1:
                rule_id = parts[1].strip()
                result = self.system['automation'].remove_rule(rule_id)
                self._pp(result)
            else:
                print("  Usage: automation remove <rule_id>")

        elif subcmd == "history":
            history = self.system['automation'].get_history(15)
            print(f"\n  ── Automation History ({len(history)}) ────────────────")
            for h in history:
                ts = h.get("timestamp", "")[:19]
                name = h.get("rule_name", "?")
                action = h.get("action_type", "?")
                print(f"  {ts} | {name} → {action}")

        else:
            print("  Automation subcommands: status, list, add, remove, history")
        print()

    def cmd_security(self, args):
        """Security operations."""
        parts = args.split(maxsplit=1)
        subcmd = parts[0].lower() if parts else "status"

        if subcmd == "status":
            status = self.system['security'].get_status()
            print("\n  ── Security Status ───────────────────────────────")
            self._pp(status)

        elif subcmd == "events":
            events = self.system['security'].get_events(15)
            print(f"\n  ── Security Events ({len(events)}) ──────────────────")
            for e in events:
                ts = e.get("timestamp", "")[:19]
                sev = e.get("severity", "?")
                etype = e.get("type", "?")
                details = e.get("details", "")
                print(f"  [{sev}] {ts} | {etype}: {details}")

        elif subcmd == "setkey":
            import getpass
            try:
                key = getpass.getpass("  Enter new master key: ")
                confirm = getpass.getpass("  Confirm master key: ")
                if key == confirm:
                    self.system['security'].set_master_key(key)
                    print("  Master key set successfully.")
                else:
                    print("  Keys do not match.")
            except (KeyboardInterrupt, EOFError):
                print("\n  Cancelled.")

        elif subcmd == "auth":
            import getpass
            try:
                key = getpass.getpass("  Enter master key: ")
                result = self.system['security'].authenticate(key)
                if result["success"]:
                    print("  ✓ Authentication successful.")
                else:
                    print(f"  ✗ {result['reason']}")
            except (KeyboardInterrupt, EOFError):
                print("\n  Cancelled.")

        elif subcmd == "override":
            if len(parts) > 1:
                import getpass
                try:
                    key = getpass.getpass("  Enter master key: ")
                    result = self.system['security'].master_override(key, parts[1].strip())
                    self._pp(result)
                except (KeyboardInterrupt, EOFError):
                    print("\n  Cancelled.")
            else:
                print("  Usage: security override <command>")
                print("  Commands: unlock, reset_threat, emergency_stop, clear_events")

        else:
            print("  Security subcommands: status, events, setkey, auth, override")
        print()

    def cmd_node(self, args):
        """Node system manager [list|spawn|kill]"""
        if not args:
            print("Usage: node [list|spawn <name> <role>|kill <id>]")
            return

        action = args[0].lower()
        ns = self.system.get('node_system') # Ensure key matches main.py

        if action == "list":
            nodes = ns.list_nodes()
            if not nodes:
                print("No active nodes.")
            else:
                print(f"\n  ── Active Nodes ({len(nodes)}) ──")
                for n in nodes:
                    print(f"  [{n['id']}] {n['name']} ({n['role']}) - {n['status']}")
                print("")

        elif action == "spawn" and len(args) >= 2:
            name = args[1]
            role = args[2] if len(args) > 2 else "worker"
            nid = ns.spawn_node(name, role)
            print(f"Node spawned: {name} [{nid}]")

        elif action == "kill" and len(args) >= 2:
            if ns.kill_node(args[1]):
                print(f"Node {args[1]} terminated.")
            else:
                print("Node not found.")
        else:
            print("Invalid node command.")


    def cmd_save(self, args):
        """Force save all memory."""
        results = self.system['memory'].save_all()
        print(f"  Memory saved: {results}")

    def cmd_clear(self, args):
        """Clear screen."""
        os.system('cls' if os.name == 'nt' else 'clear')

    def cmd_exit(self, args):
        """Shutdown and exit."""
        print("\n  Shutting down SUP Core...")
        self.running = False
