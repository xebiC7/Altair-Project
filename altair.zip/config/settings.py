"""
SUP Core - Configuration & Settings
All tunable parameters in one place.
"""

import os

# === PATHS ===
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
MEMORY_FILE = os.path.join(DATA_DIR, "memory.json")
SYSTEM_MEMORY_FILE = os.path.join(DATA_DIR, "system_memory.json")
INTELLIGENCE_MEMORY_FILE = os.path.join(DATA_DIR, "intelligence_memory.json")
EVOLUTION_LOG_DIR = os.path.join(DATA_DIR, "evolution_logs")
AUTOMATION_RULES_DIR = os.path.join(DATA_DIR, "automation_rules")
CONFIG_STATE_FILE = os.path.join(DATA_DIR, "config_state.json")
SECURITY_LOG_FILE = os.path.join(DATA_DIR, "security.log")

# === SYSTEM LIMITS ===
MAX_CPU_PERCENT = 75.0          # Never exceed this CPU usage
MAX_MEMORY_PERCENT = 70.0       # Never exceed this RAM usage
MAX_DISK_PERCENT = 90.0         # Disk usage alert threshold
BALANCE_CHECK_INTERVAL = 5.0    # Seconds between balance checks
INTELLIGENCE_TICK_INTERVAL = 3.0  # Seconds between intelligence cycles
MEMORY_AUTOSAVE_INTERVAL = 30.0   # Seconds between memory saves

# === EVOLUTION SETTINGS ===
EVOLUTION_MODE = "A"            # "A" = User Limited, "B" = Autonomous
MAX_EVOLUTION_STEPS_PER_SESSION = 50
EVOLUTION_SAFETY_SCORE_MIN = 0.7  # Minimum safety score to allow evolution step

# === AUTOMATION SETTINGS ===
AUTOMATION_ENABLED = True
MAX_AUTOMATION_RULES = 100
AUTOMATION_LEARNING_RATE = 0.1

# === SECURITY SETTINGS ===
MASTER_OVERRIDE_ENABLED = True
MAX_FAILED_AUTH_ATTEMPTS = 5
LOCKOUT_DURATION_SECONDS = 300
SECURITY_SCAN_INTERVAL = 10.0

# === INTELLIGENCE SETTINGS ===
INTELLIGENCE_HIDDEN = True       # Run silently in background
RISK_DETECTION_ENABLED = True
SMART_AUTOMATION_ENABLED = True
SELF_OPTIMIZATION_ENABLED = True

# === DISPLAY ===
SYSTEM_NAME = "ALTAIR"
VERSION = "1.0.0"
CODENAME = "Beta"

BANNER = f"""
╔══════════════════════════════════════════════════════╗
║   {SYSTEM_NAME} v{VERSION} — Codename: {CODENAME}                     ║
║   Safe & User Protector — Hidden Intelligence Core   ║
║                                                      ║
║                              Power by Aung Htet Tun  ║
╚══════════════════════════════════════════════════════╝
"""
