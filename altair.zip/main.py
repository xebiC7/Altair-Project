#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════╗
║   Altair   v1.0.0 — Safe & User Protector            ║
║   Hidden Intelligence Core — Main Entry Point        ║
║   Offline Ai         			Power by xebiC ║
╚══════════════════════════════════════════════════════╝

Run this file to start the system:
    python main.py

Requirements:
    pip install psutil  (recommended, not strictly required)
"""

import sys
import os
import signal
import time

# Ensure imports work regardless of how the script is invoked
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.dirname(SCRIPT_DIR)
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)
if PARENT_DIR not in sys.path:
    sys.path.insert(0, PARENT_DIR)

from config.settings import (
    DATA_DIR, EVOLUTION_LOG_DIR, SECURITY_LOG_FILE,
    MAX_CPU_PERCENT, MAX_MEMORY_PERCENT, MAX_DISK_PERCENT,
    BALANCE_CHECK_INTERVAL, INTELLIGENCE_TICK_INTERVAL,
    MEMORY_AUTOSAVE_INTERVAL, EVOLUTION_MODE,
    MAX_EVOLUTION_STEPS_PER_SESSION, EVOLUTION_SAFETY_SCORE_MIN,
    MAX_AUTOMATION_RULES, AUTOMATION_LEARNING_RATE,
    MAX_FAILED_AUTH_ATTEMPTS, LOCKOUT_DURATION_SECONDS,
    SYSTEM_NAME, VERSION, CODENAME,
)

from core.device_layer import DeviceLayer
from core.memory_system import MemorySystem
from core.balance_manager import BalanceManager
from core.intelligence_core import IntelligenceCore
from core.evolution_engine import EvolutionEngine
from core.automation_engine import AutomationEngine
from core.security_layer import SecurityLayer
from core.node_system import NodeSystem
from cli.interface import CLI


class SUPCore:
    """
    Main system orchestrator.
    Initializes all components in correct order and manages lifecycle.
    """

    def __init__(self):
        self.components = {}
        self._shutdown_requested = False

    def initialize(self):
        """
        Initialize all system components in order:
        1. Device Layer
        2. Memory System (auto-loads)
        3. Balance Manager
        4. Intelligence Core
        5. Evolution Engine
        6. Automation Engine
        7. Security Layer
        8. Node_system
        """
        print(f"  [{SYSTEM_NAME}] Initializing system...")

        # 1. Device Layer
        print("  [1/8] Detecting device...")
        device = DeviceLayer()
        self.components['device'] = device
        optimal = device.get_optimal_settings()
        print(f"         → {device.device_type} | {device.platform_system} | "
              f"{device.platform_machine}")

        # 2. Memory System (auto-loads from disk)
        print("  [2/8] Loading shared memory...")
        os.makedirs(DATA_DIR, exist_ok=True)
        memory = MemorySystem(DATA_DIR)
        self.components['memory'] = memory
        stats = memory.get_stats()
        print(f"         → Boot #{stats['startup_count']} | "
              f"User:{stats['user_memory_keys']} keys, "
              f"System:{stats['system_memory_keys']} keys, "
              f"Intel:{stats['intelligence_memory_keys']} keys")

        # 3. Balance Manager
        print("  [3/8] Starting balance manager...")
        balance = BalanceManager(
            max_cpu=MAX_CPU_PERCENT,
            max_memory=MAX_MEMORY_PERCENT,
            max_disk=MAX_DISK_PERCENT,
            check_interval=optimal.get("tick_interval", BALANCE_CHECK_INTERVAL),
        )
        self.components['balance'] = balance

        # 4. Intelligence Core
        print("  [4/8] Starting hidden intelligence core...")
        intelligence = IntelligenceCore(memory, balance, device)
        self.components['intelligence'] = intelligence

        # 5. Evolution Engine
        print("  [5/8] Initializing evolution engine...")
        os.makedirs(EVOLUTION_LOG_DIR, exist_ok=True)
        evolution = EvolutionEngine(
            memory, balance, intelligence,
            log_dir=EVOLUTION_LOG_DIR,
            mode=EVOLUTION_MODE,
            max_steps=MAX_EVOLUTION_STEPS_PER_SESSION,
            min_safety=EVOLUTION_SAFETY_SCORE_MIN,
        )
        self.components['evolution'] = evolution

        # 6. Automation Engine
        print("  [6/8] Starting automation engine...")
        automation = AutomationEngine(
            memory, balance,
            max_rules=MAX_AUTOMATION_RULES,
            learning_rate=AUTOMATION_LEARNING_RATE,
        )
        self.components['automation'] = automation

        # 7. Security Layer
        print("  [7/8] Activating security layer...")
        security = SecurityLayer(
            memory, balance,
            log_file=SECURITY_LOG_FILE,
            max_failed_auth=MAX_FAILED_AUTH_ATTEMPTS,
            lockout_duration=LOCKOUT_DURATION_SECONDS,
        )
        # 8. Node System
        print("  [8/8] Spawning Node Control System...")
        node_system = NodeSystem(memory)
        self.components['node_system'] = node_system
        self.components['security'] = security
        print(f"  [{SYSTEM_NAME}] All components initialized.\n")

    def start(self):
        """Start all background services."""
        # Start in dependency order
        self.components['balance'].start()
        time.sleep(2)  # Let balance manager collect initial metrics
        print(" system starding.....")
        self.components['intelligence'].start()
        self.components['evolution'].start()
        self.components['automation'].start()
        self.components['security'].start()
        self.components['memory'].start_autosave(MEMORY_AUTOSAVE_INTERVAL)

    def stop(self):
        """Stop all components gracefully."""
        print("\n  Stopping components...")
        self.components['memory'].stop_autosave()
        self.components['security'].stop()
        self.components['automation'].stop()
        self.components['evolution'].stop()
        self.components['intelligence'].stop()
        self.components['balance'].stop()

        # Final save
        print("  Saving all memory...")
        self.components['memory'].save_all()
        print(f"  [{SYSTEM_NAME}] Shutdown complete.")

    def run_cli(self):
        """Run the CLI interface."""
        cli = CLI(self.components)
        cli.start()

    def handle_signal(self, signum, frame):
        """Handle system signals for clean shutdown."""
        if not self._shutdown_requested:
            self._shutdown_requested = True
            print(f"\n  Signal {signum} received. Shutting down...")
            self.stop()
            sys.exit(0)


def main():
    """Main entry point."""
    # Create system
    sup = SUPCore()

    # Register signal handlers
    signal.signal(signal.SIGINT, sup.handle_signal)
    signal.signal(signal.SIGTERM, sup.handle_signal)

    try:
        # Initialize all components
        sup.initialize()

        # Start background services
        sup.start()

        # Give background services time to start
        time.sleep(1)

        # Run CLI
        sup.run_cli()

    except Exception as e:
        print(f"\n  [FATAL] {e}")
        import traceback
        traceback.print_exc()
    finally:
        sup.stop()


if __name__ == "__main__":
    main()
