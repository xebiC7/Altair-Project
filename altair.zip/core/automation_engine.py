"""
SUP Core - Automation Engine
Reduces repeated user actions through smart automation.
Learns from user behavior patterns.
"""

import threading
import time
import json
import os
import hashlib
from datetime import datetime
from collections import defaultdict


class AutomationRule:
    """Represents an automation rule."""

    def __init__(self, name, trigger, action, enabled=True, source="user"):
        self.id = hashlib.sha256(
            f"{name}{time.time()}".encode()
        ).hexdigest()[:12]
        self.name = name
        self.trigger = trigger  # dict: {"type": "...", "condition": "..."}
        self.action = action    # dict: {"type": "...", "params": {...}}
        self.enabled = enabled
        self.source = source    # "user" or "learned"
        self.created_at = datetime.now().isoformat()
        self.last_triggered = None
        self.trigger_count = 0
        self.confidence = 1.0 if source == "user" else 0.5

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "trigger": self.trigger,
            "action": self.action,
            "enabled": self.enabled,
            "source": self.source,
            "created_at": self.created_at,
            "last_triggered": self.last_triggered,
            "trigger_count": self.trigger_count,
            "confidence": self.confidence,
        }


class AutomationEngine:
    """
    Smart automation engine.
    - Reduces repeated user actions
    - Smart auto-execution of routine tasks
    - Adaptive learning from user behavior
    """

    def __init__(self, memory_system, balance_manager, max_rules=100,
                 learning_rate=0.1):
        self.memory = memory_system
        self.balance = balance_manager
        self.max_rules = max_rules
        self.learning_rate = learning_rate

        self._rules = {}
        self._action_history = []
        self._behavior_patterns = defaultdict(int)
        self._running = False
        self._thread = None
        self._lock = threading.RLock()
        self._action_handlers = {}

        # Built-in action handlers
        self._register_builtin_handlers()
        self._load_rules()

    def _register_builtin_handlers(self):
        """Register built-in automation action handlers."""
        self._action_handlers["log_message"] = self._action_log_message
        self._action_handlers["set_memory"] = self._action_set_memory
        self._action_handlers["adjust_balance"] = self._action_adjust_balance
        self._action_handlers["run_command"] = self._action_run_command
        self._action_handlers["alert"] = self._action_alert

    def register_handler(self, action_type, handler):
        """Register a custom action handler."""
        self._action_handlers[action_type] = handler

    def start(self):
        """Start automation engine."""
        self._running = True
        self._thread = threading.Thread(target=self._automation_loop, daemon=True)
        self._thread.start()

    def stop(self):
        """Stop automation engine."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=10)
        self._save_rules()

    def _automation_loop(self):
        """Main automation checking loop."""
        while self._running:
            sleep_time = 5.0 * self.balance.get_sleep_multiplier()
            time.sleep(sleep_time)

            if not self._running:
                break

            self._check_triggers()

    def _check_triggers(self):
        """Check all rules for trigger conditions."""
        with self._lock:
            for rule in self._rules.values():
                if not rule.enabled:
                    continue

                if self._evaluate_trigger(rule.trigger):
                    self._execute_action(rule)

    def _evaluate_trigger(self, trigger):
        """Evaluate if a trigger condition is met."""
        trigger_type = trigger.get("type", "")

        if trigger_type == "system_state":
            target_state = trigger.get("state", "")
            return self.balance.state == target_state

        elif trigger_type == "cpu_above":
            threshold = trigger.get("threshold", 80)
            metrics = self.balance.metrics
            return metrics.get("cpu_percent", 0) > threshold

        elif trigger_type == "cpu_below":
            threshold = trigger.get("threshold", 20)
            metrics = self.balance.metrics
            return metrics.get("cpu_percent", 0) < threshold

        elif trigger_type == "memory_above":
            threshold = trigger.get("threshold", 80)
            metrics = self.balance.metrics
            return metrics.get("memory_percent", 0) > threshold

        elif trigger_type == "interval":
            interval = trigger.get("seconds", 60)
            last = trigger.get("_last_run", 0)
            now = time.time()
            if now - last >= interval:
                trigger["_last_run"] = now
                return True
            return False

        elif trigger_type == "throttle_level":
            level = trigger.get("level", 2)
            return self.balance.throttle_level >= level

        return False

    def _execute_action(self, rule):
        """Execute a rule's action."""
        action_type = rule.action.get("type", "")
        handler = self._action_handlers.get(action_type)

        if handler:
            try:
                result = handler(rule.action.get("params", {}))
                rule.last_triggered = datetime.now().isoformat()
                rule.trigger_count += 1

                # Log execution
                self._action_history.append({
                    "rule_id": rule.id,
                    "rule_name": rule.name,
                    "action_type": action_type,
                    "timestamp": datetime.now().isoformat(),
                    "result": result,
                })

                # Trim history
                if len(self._action_history) > 500:
                    self._action_history = self._action_history[-500:]

            except Exception as e:
                self._action_history.append({
                    "rule_id": rule.id,
                    "error": str(e),
                    "timestamp": datetime.now().isoformat(),
                })

    # === Built-in Action Handlers ===

    def _action_log_message(self, params):
        """Log a message to system memory."""
        message = params.get("message", "Automation triggered")
        logs = self.memory.system.get("automation_logs", [])
        logs.append({
            "timestamp": datetime.now().isoformat(),
            "message": message,
        })
        if len(logs) > 100:
            logs = logs[-100:]
        self.memory.system.set("automation_logs", logs)
        return {"logged": True}

    def _action_set_memory(self, params):
        """Set a value in user memory."""
        key = params.get("key", "")
        value = params.get("value", "")
        store = params.get("store", "user")
        if key:
            getattr(self.memory, store, self.memory.user).set(key, value)
            return {"set": True, "key": key}
        return {"set": False}

    def _action_adjust_balance(self, params):
        """Adjust balance manager parameters."""
        if "max_cpu" in params:
            self.balance.max_cpu = float(params["max_cpu"])
        return {"adjusted": True}

    def _action_run_command(self, params):
        """Run a system command (sandboxed)."""
        # For safety, only allow whitelisted commands
        allowed = ["date", "uptime", "whoami", "hostname", "uname -a"]
        cmd = params.get("command", "")
        if cmd in allowed:
            import subprocess
            try:
                result = subprocess.run(
                    cmd, shell=True, capture_output=True, text=True, timeout=10
                )
                return {"output": result.stdout.strip(), "returncode": result.returncode}
            except subprocess.TimeoutExpired:
                return {"error": "Command timed out"}
        return {"error": "Command not in whitelist"}

    def _action_alert(self, params):
        """Store an alert message."""
        message = params.get("message", "Alert!")
        alerts = self.memory.system.get("alerts", [])
        alerts.append({
            "timestamp": datetime.now().isoformat(),
            "message": message,
        })
        if len(alerts) > 50:
            alerts = alerts[-50:]
        self.memory.system.set("alerts", alerts)
        return {"alerted": True}

    # === Behavior Learning ===

    def record_user_action(self, action_type, params=None):
        """
        Record a user action for behavior learning.
        Over time, the engine can suggest automation rules.
        """
        key = f"{action_type}:{json.dumps(params or {}, sort_keys=True)}"
        self._behavior_patterns[key] += 1

        # If action repeated enough times, suggest automation
        if self._behavior_patterns[key] >= 5:
            self._suggest_automation(action_type, params)

    def _suggest_automation(self, action_type, params):
        """Suggest an automation rule based on repeated behavior."""
        suggestion_key = f"suggestion_{action_type}"
        existing = self.memory.intelligence.get(suggestion_key)
        if existing:
            return  # Already suggested

        suggestion = {
            "action_type": action_type,
            "params": params,
            "times_observed": self._behavior_patterns.get(
                f"{action_type}:{json.dumps(params or {}, sort_keys=True)}", 0
            ),
            "timestamp": datetime.now().isoformat(),
            "message": f"You've performed '{action_type}' multiple times. "
                       f"Want to automate this?",
        }
        self.memory.intelligence.set(suggestion_key, suggestion)

    # === Rule Management ===

    def add_rule(self, name, trigger, action, enabled=True):
        """Add a new automation rule."""
        with self._lock:
            if len(self._rules) >= self.max_rules:
                return {"success": False, "reason": "Max rules reached"}

            rule = AutomationRule(name, trigger, action, enabled, source="user")
            self._rules[rule.id] = rule
            self._save_rules()
            return {"success": True, "rule_id": rule.id, "rule": rule.to_dict()}

    def remove_rule(self, rule_id):
        """Remove an automation rule."""
        with self._lock:
            if rule_id in self._rules:
                del self._rules[rule_id]
                self._save_rules()
                return {"success": True}
            return {"success": False, "reason": "Rule not found"}

    def enable_rule(self, rule_id, enabled=True):
        """Enable or disable a rule."""
        with self._lock:
            if rule_id in self._rules:
                self._rules[rule_id].enabled = enabled
                return {"success": True}
            return {"success": False, "reason": "Rule not found"}

    def list_rules(self):
        """List all automation rules."""
        with self._lock:
            return [r.to_dict() for r in self._rules.values()]

    def _save_rules(self):
        """Save rules to memory."""
        with self._lock:
            rules_data = {rid: r.to_dict() for rid, r in self._rules.items()}
            self.memory.system.set("automation_rules", rules_data)

    def _load_rules(self):
        """Load rules from memory."""
        rules_data = self.memory.system.get("automation_rules", {})
        for rid, rdata in rules_data.items():
            rule = AutomationRule(
                name=rdata.get("name", ""),
                trigger=rdata.get("trigger", {}),
                action=rdata.get("action", {}),
                enabled=rdata.get("enabled", True),
                source=rdata.get("source", "user"),
            )
            rule.id = rid
            rule.created_at = rdata.get("created_at", "")
            rule.last_triggered = rdata.get("last_triggered")
            rule.trigger_count = rdata.get("trigger_count", 0)
            rule.confidence = rdata.get("confidence", 1.0)
            self._rules[rid] = rule

    def get_status(self):
        """Get automation engine status."""
        with self._lock:
            return {
                "running": self._running,
                "total_rules": len(self._rules),
                "active_rules": len([r for r in self._rules.values() if r.enabled]),
                "max_rules": self.max_rules,
                "action_history_count": len(self._action_history),
                "behavior_patterns_tracked": len(self._behavior_patterns),
                "available_actions": list(self._action_handlers.keys()),
            }

    def get_history(self, limit=20):
        """Get recent automation action history."""
        return list(reversed(self._action_history[-limit:]))
