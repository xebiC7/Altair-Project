"""
SUP Core - Node System Module
Advanced distributed task management system.
Designed for stability, thread-safety, and seamless integration.
"""

import threading
import time
import uuid
from typing import Dict, List, Optional, Any

class Node:
    """Represents a single autonomous unit in the network."""
    def __init__(self, name: str, role: str = "worker", node_id: Optional[str] = None):
        self.id = node_id if node_id else str(uuid.uuid4())[:8]
        self.name = name
        self.role = role  # e.g., 'worker', 'observer', 'analyzer'
        self.status = "idle"  # idle, busy, error, offline
        self.created_at = time.time()
        self.last_active = time.time()
        self.task_history = []

    def update_status(self, status: str):
        self.status = status
        self.last_active = time.time()

    def to_dict(self) -> Dict[str, Any]:
        """Serializes node data for memory storage."""
        return {
            "id": self.id,
            "name": self.name,
            "role": self.role,
            "status": self.status,
            "created_at": self.created_at,
            "last_active": self.last_active,
            "task_count": len(self.task_history)
        }

class NodeSystem:
    """
    Manages the lifecycle and state of all Nodes.
    Integrates directly with MemorySystem for persistence.
    """
    def __init__(self, memory_system):
        self.memory = memory_system
        self.nodes: Dict[str, Node] = {}
        self._lock = threading.RLock()
        self._load_nodes()

    def spawn_node(self, name: str, role: str = "worker") -> str:
        """Creates and registers a new node."""
        with self._lock:
            new_node = Node(name, role)
            self.nodes[new_node.id] = new_node
            self._save_nodes()
            return new_node.id

    def kill_node(self, node_id: str) -> bool:
        """Removes a node from the system."""
        with self._lock:
            if node_id in self.nodes:
                del self.nodes[node_id]
                self._save_nodes()
                return True
            return False

    def get_node(self, node_id: str) -> Optional[Dict]:
        """Retrieves details of a specific node."""
        with self._lock:
            node = self.nodes.get(node_id)
            return node.to_dict() if node else None

    def list_nodes(self) -> List[Dict]:
        """Returns a list of all active nodes."""
        with self._lock:
            return [node.to_dict() for node in self.nodes.values()]

    def _save_nodes(self):
        """Persists node data to system memory."""
        data = {nid: node.to_dict() for nid, node in self.nodes.items()}
        self.memory.set_system_data("nodes", data)

    def _load_nodes(self):
        """Restores node data from system memory on startup."""
        saved_data = self.memory.get_system_data("nodes")
        if saved_data:
            with self._lock:
                for nid, data in saved_data.items():
                    self.nodes[nid] = Node(
                        name=data.get("name", "Unknown"),
                        role=data.get("role", "worker"),
                        node_id=nid
                    )
                    self.nodes[nid].status = "offline" # Reset status on load
