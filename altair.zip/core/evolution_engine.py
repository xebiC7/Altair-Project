"""
SUP Core - Evolution Engine (Dual Mode)
Mode A: User-limited evolution (safe, predictable)
Mode B: Autonomous intelligence evolution (bounded, logged)
"""

import threading
import time
import json
import os
import hashlib
from datetime import datetime
from copy import deepcopy


class EvolutionStep:
    """Represents a single evolution step."""

    def __init__(self, step_type, description, changes, safety_score,
                 mode="A", source="system"):
        self.id = hashlib.sha256(
            f"{time.time()}{description}".encode()
        ).hexdigest()[:16]
        self.step_type = step_type
        self.description = description
        self.changes = changes
        self.safety_score = safety_score
        self.mode = mode
        self.source = source
        self.timestamp = datetime.now().isoformat()
        self.applied = False
        self.reverted = False
        self.result = None

    def to_dict(self):
        return {
            "id": self.id,
            "step_type": self.step_type,
            "description": self.description,
            "changes": self.changes,
            "safety_score": self.safety_score,
            "mode": self.mode,
            "source": self.source,
            "timestamp": self.timestamp,
            "applied": self.applied,
            "reverted": self.reverted,
            "result": self.result,
        }


class EvolutionEngine:
    """
    Controlled self-evolution system.
    
    Mode A (User Limited):
    - AI improves only within rules defined by user
    - No uncontrolled system modification
    - Safe and predictable growth
    
    Mode B (Autonomous Intelligence):
    - AI can generate new ideas and optimize itself
    - Must respect safety boundaries
    - No destructive or unsafe behavior
    - All steps logged
    """

    def __init__(self, memory_system, balance_manager, intelligence_core,
                 log_dir, mode="A", max_steps=50, min_safety=0.7):
        self.memory = memory_system
        self.balance = balance_manager
        self.intelligence = intelligence_core
        self.log_dir = log_dir
        self.mode = mode
        self.max_steps_per_session = max_steps
        self.min_safety_score = min_safety

        self._steps = []
        self._pending_steps = []
        self._session_step_count = 0
        self._lock = threading.RLock()
        self._running = False
        self._thread = None
        self._user_rules = {}

        # Evolution capabilities registry
        self._capabilities = {
            "adjust_tick_interval": self._evolve_tick_interval,
            "optimize_memory": self._evolve_memory_optimization,
            "adjust_automation": self._evolve_automation_rules,
            "tune_thresholds": self._evolve_thresholds,
            "learn_patterns": self._evolve_pattern_learning,
        }

        os.makedirs(log_dir, exist_ok=True)
        self._load_history()

    def start(self):
        """Start evolution engine."""
        self._running = True
        if self.mode == "B":
            self._thread = threading.Thread(
                target=self._autonomous_loop, daemon=True
            )
            self._thread.start()

    def stop(self):
        """Stop evolution engine."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=10)
        self._save_history()

    def set_mode(self, mode):
        """Switch evolution mode."""
        if mode not in ("A", "B"):
            return False
        was_running = self._running
        if was_running:
            self.stop()
        self.mode = mode
        if was_running:
            self.start()
        self.memory.system.set("evolution_mode", mode)
        return True

    def set_user_rules(self, rules):
        """Set user-defined evolution rules."""
        self._user_rules = rules
        self.memory.user.set("evolution_rules", rules)

    # === MODE A: User-Limited Evolution ===

    def propose_step(self, step_type, description, changes):
        """
        Propose an evolution step (Mode A).
        Returns the step for user approval.
        """
        safety = self._evaluate_safety(step_type, changes)
        step = EvolutionStep(
            step_type=step_type,
            description=description,
            changes=changes,
            safety_score=safety,
            mode="A",
            source="user_proposed",
        )

        with self._lock:
            self._pending_steps.append(step)

        return step.to_dict()

    def approve_step(self, step_id):
        """Approve and apply a pending step."""
        with self._lock:
            for step in self._pending_steps:
                if step.id == step_id:
                    if step.safety_score < self.min_safety_score:
                        return {
                            "success": False,
                            "reason": f"Safety score too low: {step.safety_score}",
                        }
                    result = self._apply_step(step)
                    self._pending_steps.remove(step)
                    return result
        return {"success": False, "reason": "Step not found"}

    def reject_step(self, step_id):
        """Reject a pending step."""
        with self._lock:
            for step in self._pending_steps:
                if step.id == step_id:
                    self._pending_steps.remove(step)
                    return {"success": True, "message": "Step rejected"}
        return {"success": False, "reason": "Step not found"}

    # === MODE B: Autonomous Evolution ===

    def _autonomous_loop(self):
        """Autonomous evolution loop (Mode B only)."""
        while self._running and self.mode == "B":
            time.sleep(30 * self.balance.get_sleep_multiplier())

            if not self._running:
                break

            if self._session_step_count >= self.max_steps_per_session:
                continue

            if not self.balance.should_allow_task("medium"):
                continue

            # Generate evolution ideas
            ideas = self._generate_evolution_ideas()
            for idea in ideas:
                if not self._running:
                    break

                safety = self._evaluate_safety(idea["type"], idea["changes"])
                if safety >= self.min_safety_score:
                    step = EvolutionStep(
                        step_type=idea["type"],
                        description=idea["description"],
                        changes=idea["changes"],
                        safety_score=safety,
                        mode="B",
                        source="autonomous",
                    )
                    self._apply_step(step)

    def _generate_evolution_ideas(self):
        """Generate evolution ideas based on current intelligence."""
        ideas = []
        recommendations = self.intelligence.get_recommendations()

        for rec in recommendations:
            if rec["type"] == "OPTIMIZE_TICK":
                ideas.append({
                    "type": "adjust_tick_interval",
                    "description": f"Auto-optimize tick: {rec['reason']}",
                    "changes": {"action": rec["action"]},
                })
            elif rec["type"] == "MEMORY_CLEANUP":
                ideas.append({
                    "type": "optimize_memory",
                    "description": f"Memory optimization: {rec['reason']}",
                    "changes": {"action": "prune"},
                })

        # Pattern-based evolution
        analysis = self.memory.intelligence.get("latest_pattern_analysis", {})
        if analysis:
            avg_cpu = analysis.get("avg_cpu", 50)
            if avg_cpu < 20:
                ideas.append({
                    "type": "tune_thresholds",
                    "description": "System underutilized, lower monitoring thresholds",
                    "changes": {"cpu_threshold_delta": -5},
                })

        return ideas

    # === Core Evolution Logic ===

    def _evaluate_safety(self, step_type, changes):
        """
        Evaluate the safety of a proposed evolution step.
        Returns score from 0.0 (unsafe) to 1.0 (safe).
        """
        score = 1.0

        # Check against user rules
        if self._user_rules:
            blocked = self._user_rules.get("blocked_types", [])
            if step_type in blocked:
                return 0.0
            allowed = self._user_rules.get("allowed_types", [])
            if allowed and step_type not in allowed:
                return 0.1

        # Check system state
        if self.balance.state == "CRITICAL":
            score *= 0.3
        elif self.balance.state == "HEAVY":
            score *= 0.6

        # Check step count limits
        if self._session_step_count >= self.max_steps_per_session * 0.8:
            score *= 0.7

        # Verify step type is known
        if step_type not in self._capabilities:
            score *= 0.5

        return round(score, 2)

    def _apply_step(self, step):
        """Apply an evolution step."""
        with self._lock:
            if self._session_step_count >= self.max_steps_per_session:
                return {
                    "success": False,
                    "reason": "Session step limit reached",
                }

            # Execute the evolution capability
            capability = self._capabilities.get(step.step_type)
            if capability:
                try:
                    result = capability(step.changes)
                    step.applied = True
                    step.result = result
                    self._session_step_count += 1
                except Exception as e:
                    step.result = {"error": str(e)}
                    result = {"success": False, "error": str(e)}
            else:
                result = {"success": False, "reason": "Unknown capability"}

            self._steps.append(step)
            self._log_step(step)

            return {
                "success": step.applied,
                "step_id": step.id,
                "result": step.result,
            }

    # === Evolution Capabilities ===

    def _evolve_tick_interval(self, changes):
        """Adjust intelligence tick interval."""
        action = changes.get("action", "")
        current = self.intelligence._tick_interval

        if action == "increase_interval":
            new_val = min(current * 1.3, 20.0)
        elif action == "decrease_interval":
            new_val = max(current * 0.8, 1.0)
        else:
            return {"success": False, "reason": "Unknown action"}

        self.intelligence._tick_interval = new_val
        return {"success": True, "old": current, "new": new_val}

    def _evolve_memory_optimization(self, changes):
        """Optimize memory usage."""
        action = changes.get("action", "")
        if action == "prune":
            # Prune old intelligence observations
            obs_count = self.intelligence.memory.intelligence.get("observation_count", 0)
            return {"success": True, "pruned": True, "previous_obs": obs_count}
        return {"success": False, "reason": "Unknown action"}

    def _evolve_automation_rules(self, changes):
        """Adjust automation parameters."""
        return {"success": True, "changes_applied": changes}

    def _evolve_thresholds(self, changes):
        """Tune monitoring thresholds."""
        delta = changes.get("cpu_threshold_delta", 0)
        old = self.balance.max_cpu
        new = max(50, min(95, old + delta))
        self.balance.max_cpu = new
        return {"success": True, "old_threshold": old, "new_threshold": new}

    def _evolve_pattern_learning(self, changes):
        """Enhance pattern learning capabilities."""
        return {"success": True, "learning_enhanced": True}

    # === Logging ===

    def _log_step(self, step):
        """Log evolution step to file."""
        log_file = os.path.join(
            self.log_dir,
            f"evolution_{datetime.now().strftime('%Y%m%d')}.jsonl"
        )
        try:
            with open(log_file, "a") as f:
                f.write(json.dumps(step.to_dict(), default=str) + "\n")
        except IOError:
            pass

    def _save_history(self):
        """Save evolution history to memory."""
        self.memory.system.set("evolution_session_steps", self._session_step_count)
        self.memory.system.set("evolution_total_steps", len(self._steps))
        self.memory.system.set("evolution_mode", self.mode)

    def _load_history(self):
        """Load evolution history from memory."""
        self.mode = self.memory.system.get("evolution_mode", self.mode)
        rules = self.memory.user.get("evolution_rules")
        if rules:
            self._user_rules = rules

    # === Public API ===

    def get_status(self):
        """Get evolution engine status."""
        with self._lock:
            return {
                "mode": self.mode,
                "mode_description": "User Limited" if self.mode == "A"
                                    else "Autonomous Intelligence",
                "running": self._running,
                "session_steps": self._session_step_count,
                "max_steps_per_session": self.max_steps_per_session,
                "total_steps_applied": len([s for s in self._steps if s.applied]),
                "pending_steps": len(self._pending_steps),
                "min_safety_score": self.min_safety_score,
                "user_rules": self._user_rules,
                "capabilities": list(self._capabilities.keys()),
            }

    def get_history(self, limit=20):
        """Get recent evolution steps."""
        with self._lock:
            return [s.to_dict() for s in self._steps[-limit:]]

    def get_pending(self):
        """Get pending evolution steps."""
        with self._lock:
            return [s.to_dict() for s in self._pending_steps]

    def revert_step(self, step_id):
        """Mark a step as reverted (actual revert is best-effort)."""
        with self._lock:
            for step in self._steps:
                if step.id == step_id and step.applied:
                    step.reverted = True
                    self._log_step(step)
                    return {"success": True, "message": "Step marked as reverted"}
        return {"success": False, "reason": "Step not found or not applied"}
