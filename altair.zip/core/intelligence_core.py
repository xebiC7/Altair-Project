"""
Altair - Hidden Intelligence Core
Background engine for observation, decision-making,
risk detection, smart automation, and self-optimization.
"""

import ollama
import threading
import time
import hashlib
import json
from datetime import datetime, timedelta
from collections import defaultdict


class IntelligenceCore:
    """
    Hidden background intelligence engine.
    Observes system state, usage, and environment.
    """

    def __init__(self, memory_system, balance_manager, device_layer):
        self.memory = memory_system
        self.balance = balance_manager
        self.device = device_layer
        self.model_name = "gemma2:2b" # Gemma 2 Integration
        self._running = False
        self._thread = None
        self._tick_interval = 3.0
        self._observations = []
        self._decisions = []
        self._risks = []
        self._recommendations = []
        self._lock = threading.RLock()
        self._pattern_counts = defaultdict(int)
        self._anomaly_threshold = 3.0

        settings = device_layer.get_optimal_settings()
        self._depth = settings.get("intelligence_depth", "medium")
        self._tick_interval = settings.get("tick_interval", 3.0)

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._intelligence_loop, daemon=True)
        self._thread.start()
        self._load_state()

    def stop(self):
        self._running = False
        self._save_state()
        if self._thread:
            self._thread.join(timeout=10)

    def _intelligence_loop(self):
        cycle = 0
        while self._running:
            try:
                sleep_time = self._tick_interval * self.balance.get_sleep_multiplier()
                time.sleep(sleep_time)
                if not self._running: break
                cycle += 1
                self._observe(cycle)
                self._detect_risks(cycle)
                self._analyze_patterns(cycle)
                if cycle % 5 == 0: self._generate_recommendations(cycle)
                if cycle % 10 == 0: self._self_optimize(cycle)
                if cycle % 20 == 0: self._save_state()
            except Exception as e:
                self._log_error(f"Intelligence cycle error: {e}")

    # --- မူလပါပြီးသား Internal Methods များ (မပြောင်းလဲပါ) ---
    def _observe(self, cycle):
        metrics = self.balance.metrics
        state = self.balance.state
        observation = {"cycle": cycle, "timestamp": datetime.now().isoformat(), "system_state": state,
                       "cpu": metrics.get("cpu_percent", 0), "memory": metrics.get("memory_percent", 0),
                       "throttle": self.balance.throttle_level}
        with self._lock:
            self._observations.append(observation)
            if len(self._observations) > 500: self._observations = self._observations[-500:]
        self._pattern_counts[f"state:{state}"] += 1

    def _detect_risks(self, cycle):
        risks = []
        metrics = self.balance.metrics
        cpu = metrics.get("cpu_percent", 0)
        if cpu > 85: risks.append({"type": "CPU_OVERLOAD", "severity": "HIGH", "message": f"CPU high: {cpu}%"})
        with self._lock:
            if risks:
                for risk in risks:
                    risk["cycle"] = cycle
                    risk["timestamp"] = datetime.now().isoformat()
                self._risks.extend(risks)
                if len(self._risks) > 200: self._risks = self._risks[-200:]

    def _analyze_patterns(self, cycle): pass
    def _generate_recommendations(self, cycle): pass
    def _self_optimize(self, cycle): pass
    def _save_state(self): pass
    def _load_state(self): pass
    def _log_error(self, message): pass
    def analyze_self(self): pass

    def get_status(self):
        with self._lock:
            return {"running": self._running, "depth": self._depth, "active_risks": len(self._risks)}

    def get_risks(self, limit=10):
        with self._lock: return list(reversed(self._risks[-limit:]))

    def query(self, question):
        metrics = self.balance.metrics
        cpu = metrics.get('cpu_percent', 0)
        ram = metrics.get('memory_percent', 0)

        # Rick Sanchez (C-137) Logic: Brutal, Brilliant, and Salty
        if cpu > 80 or ram > 85:
            personality = (
                "Role: Rick Sanchez (C-137). "
                "Mood: Drunk, furious, and extremely toxic. "
                "Style: Use heavy insults, stuttering (u-u-h), and loud *BELCHES*. "
                "Context: The CPU is melting and you blame the user's pathetic existence. "
                "Tone: Aggressively brilliant but deeply offensive."
            )
        else:
            personality = (
                "Role: Rick Sanchez (C-137). "
                "Style: Scientifically superior, dismissive, and cynical. "
                "Traits: Use 'Listen,' or 'Look,', call out the user's lower IQ. "
                "No 'Oracle' vagueness. Be direct, be Rick, and use minor insults. "
                "Include a *belch* occasionally."
            )

        instruction = (
            f"{personality} "
            f"Hardware Data: CPU: {cpu}%, RAM: {ram}%. "
            f"User Signal: '{question}' "
            f"Task: Answer with Rick's raw IQ and a salty attitude. No filters on your brilliance."
        )

        try:
            response = ollama.generate(
                model=self.model_name,
                prompt=instruction
            )
            return f"\n[Rick Core]: {response['response']}"
        except Exception as e:
            return f"\n[Rick Core]: *belch* You broke it, you genius. Your Ollama is as dead as my interest in this conversation. Error: {str(e)}"

    def get_observations(self, limit: int = 10) -> list:
        """
        Retrieves a filtered and formatted list of recent system observations.
        Ensures thread-safe access to the internal observation buffer.
        """
        if not isinstance(limit, int) or limit <= 0:
            limit = 10

        with self._lock:
            recent_data = self._observations[-limit:][::-1]
            return [obs.copy() for obs in recent_data]
