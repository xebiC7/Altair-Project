"""
SUP Core - Balance Manager
Monitors and controls CPU, memory, disk, and power usage.
Ensures the system never overloads the host device.
"""

import threading
import time
import os
from datetime import datetime


class BalanceManager:
    """
    Maintains operational balance between:
    - CPU / Power usage
    - Autonomy vs Control
    - Performance vs Stability
    
    Dynamically adjusts system behavior based on resource availability.
    """

    # Operational states
    STATE_IDLE = "IDLE"
    STATE_LIGHT = "LIGHT"
    STATE_BALANCED = "BALANCED"
    STATE_HEAVY = "HEAVY"
    STATE_CRITICAL = "CRITICAL"

    def __init__(self, max_cpu=75.0, max_memory=70.0, max_disk=90.0,
                 check_interval=5.0):
        self.max_cpu = max_cpu
        self.max_memory = max_memory
        self.max_disk = max_disk
        self.check_interval = check_interval

        self._state = self.STATE_BALANCED
        self._metrics = {}
        self._history = []
        self._max_history = 100
        self._running = False
        self._thread = None
        self._lock = threading.RLock()
        self._throttle_level = 0  # 0 = none, 1 = light, 2 = medium, 3 = heavy
        self._callbacks = []
        self._has_psutil = False

        try:
            import psutil
            self._has_psutil = True
        except ImportError:
            pass

    def start(self):
        """Start the balance monitoring loop."""
        self._running = True
        self._thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._thread.start()

    def stop(self):
        """Stop monitoring."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=10)

    def register_callback(self, callback):
        """Register a callback for state changes. callback(old_state, new_state, metrics)"""
        self._callbacks.append(callback)

    def _monitor_loop(self):
        """Main monitoring loop."""
        while self._running:
            metrics = self._collect_metrics()
            new_state = self._evaluate_state(metrics)

            with self._lock:
                old_state = self._state
                self._metrics = metrics
                self._state = new_state
                self._throttle_level = self._calculate_throttle(metrics)

                # Store history
                self._history.append({
                    "timestamp": datetime.now().isoformat(),
                    "state": new_state,
                    "metrics": metrics,
                    "throttle": self._throttle_level,
                })
                if len(self._history) > self._max_history:
                    self._history = self._history[-self._max_history:]

            # Notify callbacks on state change
            if old_state != new_state:
                for cb in self._callbacks:
                    try:
                        cb(old_state, new_state, metrics)
                    except Exception:
                        pass

            time.sleep(self.check_interval)

    def _collect_metrics(self):
        """Collect current system metrics without crashing on PermissionError."""
        metrics = {
            "timestamp": datetime.now().isoformat(),
            "cpu_percent": 0.0,
            "memory_percent": 0.0,
            "memory_used_mb": 0,
            "memory_total_mb": 0,
            "disk_percent": 0.0,
            "disk_free_mb": 0,
            "process_count": 0,
            "load_average": [0.0, 0.0, 0.0],
        }

        if self._has_psutil:
            import psutil
            # CPU ဖတ်တာကို လုံးဝ ပိတ်လိုက်တာ ဒါမှမဟုတ် Try/Except လုပ်တာ အကောင်းဆုံးပဲ
            try:
                # psutil.cpu_percent က /proc/stat ကို ကိုင်လို့ Android မှာ Permission Error တက်တတ်တယ်
                metrics["cpu_percent"] = psutil.cpu_percent(interval=None) 
            except Exception:
                metrics["cpu_percent"] = 0.0

            try:
                mem = psutil.virtual_memory()
                metrics["memory_percent"] = mem.percent
                metrics["memory_used_mb"] = round(mem.used / (1024 * 1024))
                metrics["memory_total_mb"] = round(mem.total / (1024 * 1024))
            except Exception:
                pass

            try:
                disk = psutil.disk_usage("/")
                metrics["disk_percent"] = round(disk.percent, 1)
                metrics["disk_free_mb"] = round(disk.free / (1024 * 1024))
            except Exception:
                pass

            try:
                metrics["process_count"] = len(psutil.pids())
            except Exception:
                metrics["process_count"] = 0

            try:
                import os
                load = os.getloadavg()
                metrics["load_average"] = [round(l, 2) for l in load]
            except Exception:
                pass

        return metrics

    def _evaluate_state(self, metrics):
        """Determine operational state from metrics."""
        cpu = metrics["cpu_percent"]
        mem = metrics["memory_percent"]
        disk = metrics["disk_percent"]

        # Critical: any resource near maximum
        if cpu > 90 or mem > 90 or disk > 95:
            return self.STATE_CRITICAL

        # Heavy: resources under significant load
        if cpu > self.max_cpu or mem > self.max_memory or disk > self.max_disk:
            return self.STATE_HEAVY

        # Balanced: moderate usage
        if cpu > 30 or mem > 40:
            return self.STATE_BALANCED

        # Light: low usage
        if cpu > 10 or mem > 20:
            return self.STATE_LIGHT

        return self.STATE_IDLE

    def _calculate_throttle(self, metrics):
        """Calculate throttle level (0-3)."""
        cpu = metrics["cpu_percent"]
        mem = metrics["memory_percent"]

        max_load = max(cpu, mem)
        if max_load > 90:
            return 3
        elif max_load > self.max_cpu:
            return 2
        elif max_load > 50:
            return 1
        return 0

    @property
    def state(self):
        with self._lock:
            return self._state

    @property
    def throttle_level(self):
        with self._lock:
            return self._throttle_level

    @property
    def metrics(self):
        with self._lock:
            return dict(self._metrics)

    def get_sleep_multiplier(self):
        """
        Return a multiplier for sleep/tick intervals based on load.
        Higher throttle = longer sleeps = less resource usage.
        """
        multipliers = {0: 1.0, 1: 1.5, 2: 2.5, 3: 5.0}
        return multipliers.get(self.throttle_level, 1.0)

    def should_allow_task(self, task_weight="light"):
        """
        Check if a task should be allowed given current load.
        task_weight: 'light', 'medium', 'heavy'
        """
        state = self.state
        if state == self.STATE_CRITICAL:
            return False
        if state == self.STATE_HEAVY and task_weight in ("medium", "heavy"):
            return False
        if state == self.STATE_BALANCED and task_weight == "heavy":
            return False
        return True

    def get_status(self):
        """Return full status report."""
        with self._lock:
            return {
                "state": self._state,
                "throttle_level": self._throttle_level,
                "sleep_multiplier": self.get_sleep_multiplier(),
                "metrics": dict(self._metrics),
                "history_length": len(self._history),
                "limits": {
                    "max_cpu": self.max_cpu,
                    "max_memory": self.max_memory,
                    "max_disk": self.max_disk,
                },
            }
