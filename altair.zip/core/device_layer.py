"""
SUP Core - Device Abstraction Layer
Detects and adapts to: PC, Mobile (Termux), Raspberry Pi, Embedded.
"""

import platform
import os
import sys
import json
import subprocess


class DeviceLayer:
    """
    Hardware abstraction layer.
    Detects platform, capabilities, and provides unified interface.
    """

    DEVICE_PC = "PC"
    DEVICE_MOBILE = "MOBILE"
    DEVICE_RPI = "RASPBERRY_PI"
    DEVICE_EMBEDDED = "EMBEDDED"
    DEVICE_UNKNOWN = "UNKNOWN"

    def __init__(self):
        self.platform_system = platform.system()
        self.platform_machine = platform.machine()
        self.platform_node = platform.node()
        self.platform_release = platform.release()
        self.python_version = platform.python_version()
        self.device_type = self._detect_device_type()
        self.capabilities = self._detect_capabilities()

    def _detect_device_type(self):
        """Detect what kind of device we're running on."""
        # Check for Termux (Android)
        if os.environ.get("TERMUX_VERSION") or os.path.exists("/data/data/com.termux"):
            return self.DEVICE_MOBILE

        # Check for Raspberry Pi
        if self._is_raspberry_pi():
            return self.DEVICE_RPI

        # Check for embedded (very limited resources)
        if self._is_embedded():
            return self.DEVICE_EMBEDDED

        # Default: PC
        if self.platform_system in ("Linux", "Windows", "Darwin"):
            return self.DEVICE_PC

        return self.DEVICE_UNKNOWN

    def _is_raspberry_pi(self):
        """Detect Raspberry Pi via multiple methods."""
        try:
            if os.path.exists("/proc/device-tree/model"):
                with open("/proc/device-tree/model", "r") as f:
                    model = f.read().lower()
                    if "raspberry" in model:
                        return True
        except (IOError, PermissionError):
            pass

        try:
            if os.path.exists("/proc/cpuinfo"):
                with open("/proc/cpuinfo", "r") as f:
                    cpuinfo = f.read().lower()
                    if "bcm" in cpuinfo or "raspberry" in cpuinfo:
                        return True
        except (IOError, PermissionError):
            pass

        if self.platform_machine in ("armv7l", "armv6l", "aarch64"):
            if os.path.exists("/usr/bin/raspi-config"):
                return True

        return False

    def _is_embedded(self):
        """Detect embedded/minimal environment."""
        try:
            import psutil
            mem = psutil.virtual_memory()
            # Less than 512MB RAM = likely embedded
            if mem.total < 512 * 1024 * 1024:
                return True
        except ImportError:
            pass

        if self.platform_machine in ("armv6l", "mips", "mipsel"):
            return True

        return False

    def _detect_capabilities(self):
        """Detect system capabilities and available resources."""
        caps = {
            "has_psutil": False,
            "has_sqlite": False,
            "has_network": False,
            "has_gpio": False,
            "has_display": False,
            "cpu_count": 1,
            "total_memory_mb": 0,
            "disk_available_mb": 0,
        }

        # Check psutil
        try:
            import psutil
            caps["has_psutil"] = True
            caps["cpu_count"] = psutil.cpu_count() or 1
            mem = psutil.virtual_memory()
            caps["total_memory_mb"] = round(mem.total / (1024 * 1024))
            disk = psutil.disk_usage("/")
            caps["disk_available_mb"] = round(disk.free / (1024 * 1024))
        except ImportError:
            caps["cpu_count"] = os.cpu_count() or 1

        # Check sqlite
        try:
            import sqlite3
            caps["has_sqlite"] = True
        except ImportError:
            pass

        # Check network
        try:
            import socket
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(1)
            s.connect(("8.8.8.8", 80))
            caps["has_network"] = True
            s.close()
        except Exception:
            pass

        # Check GPIO (Raspberry Pi)
        try:
            import RPi.GPIO
            caps["has_gpio"] = True
        except (ImportError, RuntimeError):
            pass

        # Check display
        caps["has_display"] = bool(os.environ.get("DISPLAY") or
                                    self.platform_system == "Windows" or
                                    self.platform_system == "Darwin")

        return caps

    def get_optimal_settings(self):
        """Return device-appropriate settings."""
        settings = {
            "max_threads": 2,
            "memory_backend": "json",
            "tick_interval": 5.0,
            "autosave_interval": 60.0,
            "max_automation_rules": 50,
            "intelligence_depth": "shallow",
        }

        if self.device_type == self.DEVICE_PC:
            settings["max_threads"] = min(self.capabilities["cpu_count"], 8)
            settings["memory_backend"] = "json"
            settings["tick_interval"] = 3.0
            settings["autosave_interval"] = 30.0
            settings["max_automation_rules"] = 100
            settings["intelligence_depth"] = "deep"

        elif self.device_type == self.DEVICE_MOBILE:
            settings["max_threads"] = min(self.capabilities["cpu_count"], 4)
            settings["tick_interval"] = 5.0
            settings["autosave_interval"] = 45.0
            settings["max_automation_rules"] = 50
            settings["intelligence_depth"] = "medium"

        elif self.device_type == self.DEVICE_RPI:
            settings["max_threads"] = min(self.capabilities["cpu_count"], 4)
            settings["tick_interval"] = 5.0
            settings["autosave_interval"] = 60.0
            settings["max_automation_rules"] = 75
            settings["intelligence_depth"] = "medium"

        elif self.device_type == self.DEVICE_EMBEDDED:
            settings["max_threads"] = 1
            settings["tick_interval"] = 10.0
            settings["autosave_interval"] = 120.0
            settings["max_automation_rules"] = 20
            settings["intelligence_depth"] = "shallow"

        return settings

    def get_info(self):
        """Return device info dictionary."""
        return {
            "device_type": self.device_type,
            "platform_system": self.platform_system,
            "platform_machine": self.platform_machine,
            "platform_node": self.platform_node,
            "platform_release": self.platform_release,
            "python_version": self.python_version,
            "capabilities": self.capabilities,
            "optimal_settings": self.get_optimal_settings(),
        }

    def __repr__(self):
        return (f"DeviceLayer(type={self.device_type}, os={self.platform_system}, "
                f"arch={self.platform_machine}, "
                f"ram={self.capabilities['total_memory_mb']}MB)")
