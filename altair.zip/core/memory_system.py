"""
SUP Core - Persistent Shared Memory System
Auto-loads at startup, auto-saves during operation.
Three memory types: User, System, Intelligence.
"""

import json
import os
import time
import threading
import copy
from datetime import datetime

# Import settings
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class MemoryStore:
    """
    A single persistent memory store backed by a JSON file.
    Thread-safe with auto-save capability.
    """

    def __init__(self, filepath, name="memory"):
        self.filepath = filepath
        self.name = name
        self._data = {}
        self._lock = threading.RLock()
        self._dirty = False
        self._load()

    def _load(self):
        """Load memory from disk."""
        with self._lock:
            if os.path.exists(self.filepath):
                try:
                    with open(self.filepath, "r") as f:
                        self._data = json.load(f)
                except (json.JSONDecodeError, IOError) as e:
                    # Corrupted file — backup and start fresh
                    backup = self.filepath + f".backup.{int(time.time())}"
                    try:
                        os.rename(self.filepath, backup)
                    except OSError:
                        pass
                    self._data = {}
            else:
                self._data = {}

    def save(self):
        """Save memory to disk."""
        with self._lock:
            if not self._dirty:
                return False
            os.makedirs(os.path.dirname(self.filepath), exist_ok=True)
            try:
                # Write to temp file first for atomicity
                tmp_path = self.filepath + ".tmp"
                with open(tmp_path, "w") as f:
                    json.dump(self._data, f, indent=2, default=str)
                os.replace(tmp_path, self.filepath)
                self._dirty = False
                return True
            except IOError as e:
                return False

    def get(self, key, default=None):
        """Get a value from memory."""
        with self._lock:
            keys = key.split(".") if "." in key else [key]
            data = self._data
            for k in keys:
                if isinstance(data, dict) and k in data:
                    data = data[k]
                else:
                    return default
            return copy.deepcopy(data)

    def set(self, key, value):
        """Set a value in memory."""
        with self._lock:
            keys = key.split(".") if "." in key else [key]
            data = self._data
            for k in keys[:-1]:
                if k not in data or not isinstance(data[k], dict):
                    data[k] = {}
                data = data[k]
            data[keys[-1]] = value
            self._dirty = True

    def delete(self, key):
        """Delete a key from memory."""
        with self._lock:
            keys = key.split(".") if "." in key else [key]
            data = self._data
            for k in keys[:-1]:
                if isinstance(data, dict) and k in data:
                    data = data[k]
                else:
                    return False
            if keys[-1] in data:
                del data[keys[-1]]
                self._dirty = True
                return True
            return False

    def keys(self, prefix=None):
        """List all top-level keys, optionally filtered by prefix."""
        with self._lock:
            if prefix:
                return [k for k in self._data.keys() if k.startswith(prefix)]
            return list(self._data.keys())

    def all(self):
        """Return full memory snapshot."""
        with self._lock:
            return copy.deepcopy(self._data)

    def clear(self):
        """Clear all memory."""
        with self._lock:
            self._data = {}
            self._dirty = True

    def size(self):
        """Return approximate memory size in bytes."""
        with self._lock:
            return len(json.dumps(self._data, default=str))


class MemorySystem:
    """
    Complete memory system with three stores:
    - User Memory: preferences, behavior patterns, custom data
    - System Memory: logs, optimization data, runtime state
    - Intelligence Memory: AI-learned patterns, models, decisions
    
    Features auto-load at startup and auto-save on interval.
    """

    def __init__(self, data_dir):
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)

        # Initialize three memory stores
        self.user = MemoryStore(
            os.path.join(data_dir, "user_memory.json"), "user"
        )
        self.system = MemoryStore(
            os.path.join(data_dir, "system_memory.json"), "system"
        )
        self.intelligence = MemoryStore(
            os.path.join(data_dir, "intelligence_memory.json"), "intelligence"
        )

        # Autosave thread
        self._autosave_thread = None
        self._autosave_running = False
        self._autosave_interval = 30.0

        # Record startup
        self.system.set("last_startup", datetime.now().isoformat())
        startup_count = self.system.get("startup_count", 0)
        self.system.set("startup_count", startup_count + 1)

    def start_autosave(self, interval=30.0):
        """Start automatic periodic saving."""
        self._autosave_interval = interval
        self._autosave_running = True
        self._autosave_thread = threading.Thread(
            target=self._autosave_loop, daemon=True
        )
        self._autosave_thread.start()

    def stop_autosave(self):
        """Stop automatic saving and do final save."""
        self._autosave_running = False
        if self._autosave_thread:
            self._autosave_thread.join(timeout=5)
        self.save_all()

    def _autosave_loop(self):
        """Background autosave loop."""
        while self._autosave_running:
            time.sleep(self._autosave_interval)
            if self._autosave_running:
                self.save_all()

    def save_all(self):
        """Save all memory stores."""
        results = {
            "user": self.user.save(),
            "system": self.system.save(),
            "intelligence": self.intelligence.save(),
        }
        return results

    def get_stats(self):
        """Return memory system statistics."""
        return {
            "user_memory_keys": len(self.user.keys()),
            "user_memory_size": self.user.size(),
            "system_memory_keys": len(self.system.keys()),
            "system_memory_size": self.system.size(),
            "intelligence_memory_keys": len(self.intelligence.keys()),
            "intelligence_memory_size": self.intelligence.size(),
            "startup_count": self.system.get("startup_count", 0),
            "last_startup": self.system.get("last_startup", "N/A"),
            "autosave_active": self._autosave_running,
            "autosave_interval": self._autosave_interval,
        }

    def export_all(self):
        """Export all memory as a single dict."""
        return {
            "user": self.user.all(),
            "system": self.system.all(),
            "intelligence": self.intelligence.all(),
            "exported_at": datetime.now().isoformat(),
        }

    def search(self, query):
        """Search across all memory stores for matching keys/values."""
        results = []
        query_lower = query.lower()
        for store_name, store in [("user", self.user),
                                   ("system", self.system),
                                   ("intelligence", self.intelligence)]:
            data = store.all()
            self._search_recursive(data, store_name, query_lower, results)
        return results

    def _search_recursive(self, data, path, query, results):
        """Recursively search dict for query matches."""
        if isinstance(data, dict):
            for key, value in data.items():
                current_path = f"{path}.{key}"
                if query in key.lower():
                    results.append({"path": current_path, "value": value})
                if isinstance(value, str) and query in value.lower():
                    results.append({"path": current_path, "value": value})
                elif isinstance(value, dict):
                    self._search_recursive(value, current_path, query, results)

    def get_system_data(self, key):
        """NodeSystem ကဲ့သို့သော component များအတွက် system data ကို လှမ်းဖတ်ပေးရန်"""
        return self.system.get(key)

    def set_system_data(self, key, value):
        """NodeSystem ကဲ့သို့သော component များအတွက် system data ကို သိမ်းဆည်းရန်"""
        self.system.set(key, value)
        self.save_all() # Data ပြောင်းလဲတိုင်း disk ပေါ်သို့ ချက်ချင်းသိမ်းမည်
