"""
SUP Core - Security & Protection Layer
Protects user system from misuse, instability, and unauthorized control.
"""

import threading
import time
import hashlib
import os
import json
import logging
from datetime import datetime


class SecurityLayer:
    """
    Digital guardian system.
    - Monitors for threats and anomalies
    - Prevents unauthorized control
    - Maintains system integrity
    - Provides master override capability
    """

    THREAT_NONE = "NONE"
    THREAT_LOW = "LOW"
    THREAT_MEDIUM = "MEDIUM"
    THREAT_HIGH = "HIGH"
    THREAT_CRITICAL = "CRITICAL"

    def __init__(self, memory_system, balance_manager, log_file,
                 max_failed_auth=5, lockout_duration=300):
        self.memory = memory_system
        self.balance = balance_manager
        self.log_file = log_file
        self.max_failed_auth = max_failed_auth
        self.lockout_duration = lockout_duration

        self._running = False
        self._thread = None
        self._lock = threading.RLock()
        self._threat_level = self.THREAT_NONE
        self._security_events = []
        self._failed_auth_count = 0
        self._locked_out = False
        self._lockout_until = None
        self._master_key_hash = None
        self._integrity_hashes = {}

        # Setup logging
        self._setup_logging()
        self._load_state()

    def _setup_logging(self):
        """Setup security logger."""
        os.makedirs(os.path.dirname(self.log_file), exist_ok=True)
        self._logger = logging.getLogger("SUP_Security")
        self._logger.setLevel(logging.INFO)
        if not self._logger.handlers:
            handler = logging.FileHandler(self.log_file)
            handler.setFormatter(
                logging.Formatter('%(asctime)s [%(levelname)s] %(message)s')
            )
            self._logger.addHandler(handler)

    def start(self):
        """Start security monitoring."""
        self._running = True
        self._thread = threading.Thread(target=self._security_loop, daemon=True)
        self._thread.start()
        self._log_event("SYSTEM", "Security layer started")

    def stop(self):
        """Stop security monitoring."""
        self._running = False
        self._log_event("SYSTEM", "Security layer stopped")
        self._save_state()
        if self._thread:
            self._thread.join(timeout=10)

    def _security_loop(self):
        """Main security monitoring loop."""
        while self._running:
            time.sleep(10 * self.balance.get_sleep_multiplier())

            if not self._running:
                break

            self._check_system_integrity()
            self._check_resource_abuse()
            self._check_lockout_expiry()
            self._assess_threat_level()

    def _check_system_integrity(self):
        """Verify system files haven't been tampered with."""
        # Check critical memory files
        data_dir = self.memory.data_dir
        for filename in os.listdir(data_dir):
            filepath = os.path.join(data_dir, filename)
            if os.path.isfile(filepath) and filepath.endswith(".json"):
                try:
                    current_hash = self._hash_file(filepath)
                    old_hash = self._integrity_hashes.get(filepath)

                    if old_hash and current_hash != old_hash:
                        # File changed — could be normal (autosave) or tampering
                        # Only flag if change happened outside our save cycle
                        pass

                    self._integrity_hashes[filepath] = current_hash
                except (IOError, PermissionError):
                    pass

    def _check_resource_abuse(self):
        """Check for resource abuse patterns."""
        metrics = self.balance.metrics
        cpu = metrics.get("cpu_percent", 0)
        mem = metrics.get("memory_percent", 0)

        if cpu > 95 and mem > 90:
            self._log_event("WARNING", f"Extreme resource usage: CPU={cpu}%, MEM={mem}%")
            self._add_security_event("RESOURCE_ABUSE", self.THREAT_HIGH,
                                     f"CPU={cpu}%, MEM={mem}%")

    def _check_lockout_expiry(self):
        """Check if lockout has expired."""
        if self._locked_out and self._lockout_until:
            if datetime.now() > self._lockout_until:
                self._locked_out = False
                self._failed_auth_count = 0
                self._lockout_until = None
                self._log_event("SYSTEM", "Lockout expired")

    def _assess_threat_level(self):
        """Assess overall threat level."""
        with self._lock:
            # Count recent security events
            recent = [e for e in self._security_events[-20:]
                     if e.get("severity") in (self.THREAT_HIGH, self.THREAT_CRITICAL)]

            if len(recent) >= 5:
                self._threat_level = self.THREAT_CRITICAL
            elif len(recent) >= 3:
                self._threat_level = self.THREAT_HIGH
            elif len(recent) >= 1:
                self._threat_level = self.THREAT_MEDIUM
            elif self._security_events:
                self._threat_level = self.THREAT_LOW
            else:
                self._threat_level = self.THREAT_NONE

    # === Authentication ===

    def set_master_key(self, key):
        """Set the master override key."""
        self._master_key_hash = hashlib.sha256(key.encode()).hexdigest()
        self.memory.system.set("master_key_hash", self._master_key_hash)
        self._log_event("AUTH", "Master key set")
        return True

    def authenticate(self, key):
        """Authenticate with master key."""
        if self._locked_out:
            remaining = 0
            if self._lockout_until:
                remaining = max(0, (self._lockout_until - datetime.now()).total_seconds())
            return {
                "success": False,
                "reason": f"Locked out. Wait {int(remaining)} seconds.",
            }

        if not self._master_key_hash:
            # No key set — allow access
            return {"success": True, "reason": "No master key configured"}

        key_hash = hashlib.sha256(key.encode()).hexdigest()
        if key_hash == self._master_key_hash:
            self._failed_auth_count = 0
            self._log_event("AUTH", "Successful authentication")
            return {"success": True}
        else:
            self._failed_auth_count += 1
            self._log_event("AUTH", f"Failed authentication (attempt {self._failed_auth_count})")
            self._add_security_event("FAILED_AUTH", self.THREAT_MEDIUM,
                                     f"Attempt {self._failed_auth_count}")

            if self._failed_auth_count >= self.max_failed_auth:
                self._locked_out = True
                from datetime import timedelta
                self._lockout_until = datetime.now() + timedelta(
                    seconds=self.lockout_duration
                )
                self._log_event("AUTH", f"Account locked for {self.lockout_duration}s")
                self._add_security_event("LOCKOUT", self.THREAT_HIGH,
                                         f"Too many failed attempts")

            return {
                "success": False,
                "reason": "Invalid key",
                "attempts_remaining": self.max_failed_auth - self._failed_auth_count,
            }

    def master_override(self, key, command):
        """Execute a master override command."""
        auth = self.authenticate(key)
        if not auth["success"]:
            return auth

        self._log_event("OVERRIDE", f"Master override: {command}")

        if command == "unlock":
            self._locked_out = False
            self._failed_auth_count = 0
            return {"success": True, "message": "System unlocked"}

        elif command == "reset_threat":
            self._threat_level = self.THREAT_NONE
            self._security_events = []
            return {"success": True, "message": "Threat level reset"}

        elif command == "emergency_stop":
            return {"success": True, "message": "Emergency stop requested",
                    "action": "emergency_stop"}

        elif command == "clear_events":
            self._security_events = []
            return {"success": True, "message": "Security events cleared"}

        return {"success": False, "reason": f"Unknown command: {command}"}

    # === Event Management ===

    def _add_security_event(self, event_type, severity, details=""):
        """Add a security event."""
        event = {
            "type": event_type,
            "severity": severity,
            "details": details,
            "timestamp": datetime.now().isoformat(),
        }
        with self._lock:
            self._security_events.append(event)
            if len(self._security_events) > 500:
                self._security_events = self._security_events[-500:]

    def _log_event(self, category, message):
        """Log a security event."""
        self._logger.info(f"[{category}] {message}")

    # === Utility ===

    def _hash_file(self, filepath):
        """Calculate SHA256 hash of a file."""
        sha256 = hashlib.sha256()
        with open(filepath, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                sha256.update(chunk)
        return sha256.hexdigest()

    def _save_state(self):
        """Save security state."""
        self.memory.system.set("security_threat_level", self._threat_level)
        self.memory.system.set("security_events_count", len(self._security_events))
        self.memory.system.set("security_failed_auth", self._failed_auth_count)

    def _load_state(self):
        """Load security state."""
        self._master_key_hash = self.memory.system.get("master_key_hash")

    # === Public API ===

    def get_status(self):
        """Get security status."""
        with self._lock:
            return {
                "threat_level": self._threat_level,
                "locked_out": self._locked_out,
                "failed_auth_attempts": self._failed_auth_count,
                "max_failed_auth": self.max_failed_auth,
                "master_key_set": self._master_key_hash is not None,
                "security_events_count": len(self._security_events),
                "recent_events": self._security_events[-5:],
                "running": self._running,
            }

    def get_events(self, limit=20):
        """Get recent security events."""
        with self._lock:
            return list(reversed(self._security_events[-limit:]))

    def validate_action(self, action_type, params=None):
        """
        Validate if an action should be allowed.
        Returns (allowed: bool, reason: str)
        """
        if self._locked_out:
            return False, "System is locked"

        if self._threat_level == self.THREAT_CRITICAL:
            if action_type not in ("status", "authenticate", "master_override"):
                return False, "System under critical threat"

        # Block dangerous actions
        dangerous = ["delete_all_memory", "disable_security", "root_access"]
        if action_type in dangerous:
            self._add_security_event("BLOCKED_ACTION", self.THREAT_HIGH,
                                     f"Blocked: {action_type}")
            return False, f"Action '{action_type}' is blocked for safety"

        return True, "Allowed"
