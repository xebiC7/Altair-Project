import os
import sys
from flask import Flask, render_template, request, jsonify

# Project path သတ်မှတ်ခြင်း
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.intelligence_core import IntelligenceCore
from core.memory_system import MemorySystem
from core.balance_manager import BalanceManager
from core.device_layer import DeviceLayer

app = Flask(__name__, template_folder='web/templates', static_folder='web/static')

# Component များ တည်ဆောက်ခြင်း
DATA_DIR = os.path.join(os.getcwd(), "data")
balance = BalanceManager()
balance.start()
memory = MemorySystem(DATA_DIR)
memory.start_autosave()
device = DeviceLayer()

# Rick Core ကို Component များဖြင့် ချိတ်ဆက်ခြင်း
rick_brain = IntelligenceCore(memory, balance, device)
rick_brain.start()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.json.get('message', '')
    response_text = rick_brain.query(user_input) # Rick Core ဆီမှ အဖြေတောင်းခြင်း
    return jsonify({'response': response_text})

@app.route('/api/full_status')
def get_full_status():
    metrics = balance.metrics #
    status = rick_brain.get_status() #
    return jsonify({
        'ram': metrics.get('memory_percent', 0),
        'swarm_agents': status.get('active_risks', 0) + 3
    })

if __name__ == '__main__':
    try:
        app.run(host='0.0.0.0', port=5000, debug=False)
    finally:
        rick_brain.stop()
        balance.stop()
        memory.stop_autosave()

