#!/usr/bin/env python3
import os

# လက်ရှိ folder နာမည်ကို အခြေခံမယ်
BASE_DIR = "." 

DIRS = [
    "config",
    "core",
    "cli",
    "data",
    "data/evolution_logs",
    "data/automation_rules",
]

INIT_FILES = [
    "__init__.py",
    "config/__init__.py",
    "core/__init__.py",
    "cli/__init__.py",
]

def setup():
    for d in DIRS:
        os.makedirs(os.path.join(BASE_DIR, d), exist_ok=True)
        print(f"[+] Directory: {d}")
    for f in INIT_FILES:
        file_path = os.path.join(BASE_DIR, f)
        if not os.path.exists(file_path):
            open(file_path, 'w').close()
            print(f"[+] Init file: {f}")
    print("\n[OK] Project structure fixed. Run: python main.py")

if __name__ == "__main__":
    setup()
